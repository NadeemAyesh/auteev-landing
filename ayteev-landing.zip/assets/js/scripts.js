/*global $, jQuery, console, alert, prompt */
$(document).ready(function () {
    "use strict";
    const observer = lozad(); // lazy loads elements with default selector as '.lozad'
    observer.observe();

    $('.menu-btn').on('click', function () {
        $('.left-slide-nav').toggleClass('show');

        $('.close-menu').on('click', function () {
            $('.left-slide-nav').removeClass('show');
        });
    });
});